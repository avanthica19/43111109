package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.model.Seller;
import com.example.demo.service.BookService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class BookController {

    @Autowired
    private BookService bookService;

    // 🟢 HOME PAGE – show all books (BUYERS + SELLERS)
    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("listBooks", bookService.getAllBooks());
        return "index";
    }

    // 🟢 SHOW ADD BOOK FORM – ONLY LOGGED-IN SELLERS
    @GetMapping("/showNewBookForm")
    public String showNewBookForm(Model model, HttpSession session) {

        Seller seller = (Seller) session.getAttribute("loggedSeller");

        if (seller == null) {
            return "redirect:/login";
        }

        Book book = new Book();
        model.addAttribute("book", book);
        return "new_book";
    }

    // 🟢 SAVE BOOK – ATTACH SELLER DETAILS
    @PostMapping("/saveBook")
    public String saveBook(@ModelAttribute("book") Book book, HttpSession session) {

        Seller seller = (Seller) session.getAttribute("loggedSeller");

        if (seller == null) {
            return "redirect:/login";
        }

        // attach seller info
        book.setSellerName(seller.getName());
        book.setSellerPhone(seller.getPhone());
        book.setStatus("AVAILABLE");

        bookService.saveBook(book);
        return "redirect:/";
    }

    // 🟢 DELETE BOOK – ONLY LOGGED-IN SELLER
    @GetMapping("/deleteBook/{id}")
    public String deleteBook(@PathVariable(value = "id") int id, HttpSession session) {

        Seller seller = (Seller) session.getAttribute("loggedSeller");

        if (seller == null) {
            return "redirect:/login";
        }

        bookService.deleteBook(id);
        return "redirect:/";
    }
}
